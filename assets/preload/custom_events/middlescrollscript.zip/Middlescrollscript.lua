function onMoveCamera(focus)
	if focus == 'boyfriend' then
	noteTweenX("NoteMove1", 0, 0, 0.2, cubeInOut)
	noteTweenX("NoteMove2", 1, 112, 0.2, cubeInOut)
	noteTweenX("NoteMove3", 2, 1063, 0.2, cubeInOut)
	noteTweenX("NoteMove4", 3, 1175, 0.2, cubeInOut)

        noteTweenAlpha("NoteAlpha1", 0, 0.8, 0.4, linear)
        noteTweenAlpha("NoteAlpha2", 1, 0.8, 0.4, linear)
        noteTweenAlpha("NoteAlpha3", 2, 0.8, 0.4, linear)
        noteTweenAlpha("NoteAlpha4", 3, 0.8, 0.4, linear)
	elseif focus == 'dad' then
	noteTweenX("NoteMove5", 0, 410, 0.2, cubeInOut)
	noteTweenX("NoteMove6", 1, 525, 0.2, cubeInOut)
	noteTweenX("NoteMove7", 2, 637, 0.2, cubeInOut)
	noteTweenX("NoteMove8", 3, 749, 0.2, cubeInOut)

        noteTweenAlpha("NoteAlpha13", 0, 0.2, 0.4, linear)
        noteTweenAlpha("NoteAlpha14", 1, 0.2, 0.4, linear)
        noteTweenAlpha("NoteAlpha15", 2, 0.2, 0.4, linear)
        noteTweenAlpha("NoteAlpha16", 3, 0.2, 0.4, linear)
	end
end
